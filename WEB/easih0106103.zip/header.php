<div id="topcontainer">
	<h1><a href="index.php" id="topbanner"><span class="hidden">EASIH - The Eastern Sequence and Informatics Hub - Part of University of Cambridge - Addenbrooke's Hospital</span></a></h1>
</div>
<div id="navcontainer">
	<div id="navarea">
		<ul>
<?php
//			<li class="navarea-technologies"><a href="technologies.php" title="Technologies" tabindex="1" accesskey="1"><span class="hidden">Technologies</span></a></li>
?>
			<li class="navarea-sequencingapplications"><a href="sequencingapplications.php" title="Sequencing Applications" tabindex="2" accesskey="2"><span class="hidden">Sequencing Applications</span></a></li>
<?php
//			<li class="navarea-publications"><a href="publications.php" title="Publications" tabindex="3" accesskey="3"><span class="hidden">Publications</span></a></li>
?>
			<li class="navarea-bioinformatics"><a href="bioinformatics.php" title="BioInformatics" tabindex="4" accesskey="4"><span class="hidden">BioInformatics</span></a></li>
			<li class="navarea-serviceinformation"><a href="serviceinformation.php" title="Service Information" tabindex="5" accesskey="5"><span class="hidden">Service Information</span></a></li>
			<li class="navarea-enquiries"><a href="enquiries.php" title="Enquiries" tabindex="6" accesskey="6"><span class="hidden">Enquiries</span></a></li>
		</ul>
	</div>
</div>
