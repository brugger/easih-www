<div id="footercontainer">
	<div id="footer">
    	<div class="leftcol">&copy; EASIH <?php echo date("Y")?>. All rights reserved.</div>
        <div class="rightcol">Site by <a href="http://www.ceneydesign.co.uk" target="_blank">Ceney Design</a> : <a href="sitemap.php">Sitemap</a></div>
    </div>
</div>
